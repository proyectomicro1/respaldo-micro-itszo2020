<?php include("dash-arriba.html");?>
<?php include("boots.php");?>
<html>
<head><title>Registrar Salidas</title></head>
<body>
<form action="reg-salidas.php" method="post">
  <div class="form-group">
    <label for="formGroupExampleInput">Id Persona que solicita el articulo/producto</label>
    <input type="text" class="form-control" id="personal" placeholder="16040073" name="personal">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Producto</label>
    <input type="text" class="form-control" id="material" name="material" placeholder="Material">
  </div>
  <div class="form-group">
    <label for="formGroupExampleInput2">Cantidad</label>
    <input type="text" class="form-control" id="cantidad" name="cantidad" placeholder="12">
  </div>
  <button type="submit" class="btn btn-primary btn-lg btn-block">Salida</button>
</form>
</body>
</html>
