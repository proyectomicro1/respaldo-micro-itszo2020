<?php include("dash-arriba.html");?>
<?php include("boots.php");?>
<!DOCTYPE html>

<head>
<meta charset="utf-8">
<title>Eliminar Numeros de Acceso</title>


</head>
<body>
	<h1 align="center">Eliminar Usuarios </h1>
	<p align="center">Usuarios que tienen numero de control.</p>
	<br><br>
	<?php
	include("function.php");
	?>
	<div class="center">
		<table align="center" border="1" class="table table-hover">
			<tr>
				<th WIDTH="800" scope="col">Numeros de acceso.</th>
				<th>Eliminar</th>
			</tr>
		<?php 
			$sql = "select * from n_control";
			$result = db_query($sql);
			while($row = mysqli_fetch_object($result)){
		?>
		<tr>
			<td WIDTH="80" HEIGHT="20"><?php echo $row->numero_control;?></td>
			<td>
 	  <a class="btn btn-danger " href="borrarusuarios.php?numero_control=<?php echo $row->numero_control;?>"><i class="fa fa-trash-o fa-lg" aria-hidden="true"></i></a>
    	    </td>
		</tr>
		<?php } ?>
		</table>
	</div>
</body>
</html>