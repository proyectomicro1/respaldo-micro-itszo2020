<?php
function db_query($query) {
    $connection = mysqli_connect("localhost","root","","prototipo");
    $result = mysqli_query($connection,$query);

    return $result;
}

function delete($personal,$ids,$id){

	$sql = "delete from ".$personal." where ".$ids."=".$id."";
	
	return db_query($sql);
}

function select_id($personal,$ids,$id){
	$sql = "Select * from ".$personal." where ".$ids." = ".$id."";
	$db=db_query($sql);
	$GLOBALS['row'] = mysqli_fetch_object($db);

	return $sql;

}
?>
