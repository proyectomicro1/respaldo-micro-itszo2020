
<?php 

  $conexion=mysqli_connect('localhost','root','','micro');

 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Salidas ITSZO</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link id="template-file" href="dash.html" rel="import" />  
  </head>
  <body>
  <?php include("dash-arriba.html");?>
   <?php include("boots.php");?>

    <h1>Salidas ITSZO</h1>
    <br>
    <button type="button" class="btn btn-danger btn-lg btn-block" onclick="" ><a href="borrar-salidas.php">Borrar todas las salidas</a></button>
    <table border="1" align="center" class="table table-hover">
    <thead>
    <tr>
      <th  scope="col">Numero de control.</th>
      <th  scope="col">Preferencia.</th>
      <th  scope="col">Hora de Salida</th>
      <th  scope="col">Fecha de Salida</th>
    </tr>
    </thead>
    <?php 
    $sql="SELECT * from salida,n_control";
    $result=mysqli_query($conexion,$sql);
    while($mostrar=mysqli_fetch_array($result)){
     ?>
     
     <tbody>
    <tr>
      <th scope="row"><?php echo $mostrar['numero_control'] ?></th>
      <th scope="row"><?php echo $mostrar['preferencia'] ?></th>
      <th scope="row"><?php echo $mostrar['hora_salida'] ?></th>
      <th scope="row"><?php echo $mostrar['fecha_salida'] ?></th>

    </tr>
  </tbody>
  <?php 
  }
   ?>
  </table>
  </body>
</html>
