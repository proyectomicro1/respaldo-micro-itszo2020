<?php
$servername = "localhost";
$database = "prototipo";
$username = "root";
$password = "";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}
 
echo "------>";

$personal = $_POST['personal'];
$material = $_POST['material'];
$cantidad = $_POST['cantidad'];
$sql = "INSERT INTO salida_a (personal, material, cantidad, hora,fecha_salida) VALUES ('$personal','$material', '$cantidad',NOW(),NOW())";
if (mysqli_query($conn, $sql)) {

      $vars = "Datos guardados correctamente";
      echo "<script> alert('".$vars."'); </script>";
      
} else {
      echo "Error en captura de datos: " . $sql . "<br>" . mysqli_error($conn);
}
$sql = "INSERT INTO salida_b (personal, material, cantidad, hora,fecha_salida) VALUES ('$personal','$material', '$cantidad',NOW(),NOW())";
if (mysqli_query($conn, $sql)) {

      $vars = "Datos guardados correctamente";
      echo "<script> alert('".$vars."'); </script>";
      
} else {
      echo "Error en captura de datos: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
<?php
 header('Location: registrar-salidas.php');s
?>