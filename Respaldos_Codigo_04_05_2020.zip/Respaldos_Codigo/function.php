<?php
function db_query($query) {
    $connection = mysqli_connect("localhost","root","","micro");
    $result = mysqli_query($connection,$query);

    return $result;
}

function delete($n_control,$n_controls,$numero_control){

	$sql = "delete from ".$n_control." where ".$n_controls."=".$numero_control."";
	
	return db_query($sql);
}

function select_id($n_control,$n_controls,$numero_control){
	$sql = "Select * from ".$n_control." where ".$n_controls." = ".$numero_control."";
	$db=db_query($sql);
	$GLOBALS['row'] = mysqli_fetch_object($db);

	return $sql;

}
?>
