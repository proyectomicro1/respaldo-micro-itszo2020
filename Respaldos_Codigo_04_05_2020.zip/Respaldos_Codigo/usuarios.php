
<?php


  require 'database.php';
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>SIES</title>
    <link href="https://fonts.google.com/specimen/Orbitron" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>
    <?php require 'dash.html' ?>
      <div>
        <br>
        <br>
        <br>
        <br>
        <br>
      <p><h3>Dame el usuario a eliminar</h3></p>
    </div>
     <form action="eliminarusuario.php" method="post">
      <input name="npersona" type="text" placeholder="usuario">
      <input type="submit" value="Analizar">
    </form>
  </body>
</html>
