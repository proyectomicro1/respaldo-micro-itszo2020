<?php 
include("funcion-personal.php");
$ids = $_GET['id'];
delete('personal','id',$ids);
header("location:e-personal.php");
?>