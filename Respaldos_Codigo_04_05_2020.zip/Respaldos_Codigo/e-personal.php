<?php include("dash-arriba.html");?>
<?php include("boots.php");?>
<!DOCTYPE html>

<head>
<meta charset="utf-8">
<title>Eliminar Personal</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
	
	<h1 align="center">Personal </h1>
	<br><br>
	<?php
	include("funcion-personal.php");
	?>
	<div class="center">
		<table border="1" align="center" class="table table-hover">
			<thead>
			<tr>
				<th scope="col">Id</th>
				<th scope="col">Nombre</th>
				<th scope="col">Apellido P</th>
				<th scope="col">Apellido M</th>
				<th scope="col">Eliminar</th>
			</tr>
		</thead>
		<?php 
			$sql = "select * from personal";
			$result = db_query($sql);
			while($row = mysqli_fetch_object($result)){
		?>
		<tbody>
		<tr>
			<th scope="row"><?php echo $row->id;?></th>
			<th scope="row"><?php echo $row->nombre;?></th>
			<th scope="row"><?php echo $row->a_paterno;?></th>
			<th scope="row"><?php echo $row->a_materno;?></th>
			<th scope="row"> 
 	  <a class="btn btn-danger " href="eliminar-personal.php?id=<?php echo $row->id;?>"><i class="fa fa-trash-o fa-lg" aria-hidden="true"></i></a>
    	    </th>
		</tr>
	</tbody>
		<?php } ?>

	</div>
</body>
</html>