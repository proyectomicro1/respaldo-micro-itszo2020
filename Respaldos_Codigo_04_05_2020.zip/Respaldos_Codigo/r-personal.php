<?php
$servername = "localhost";
$database = "micro";
$username = "root";
$password = "";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}
 
echo "------>";

$numero_control = $_POST['numero_control'];
$preferencia= $_POST['preferencia'];
$sql = "INSERT INTO n_control (numero_control, preferencia) VALUES ('$numero_control','$preferencia')";
if (mysqli_query($conn, $sql)) {

      $vars = "Datos guardados correctamente";
      echo "<script> alert('".$vars."'); </script>";
      
} else {
      echo "Error en captura de datos: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
<?php
 header('Location: registrar-personal.php');s
?>