<?php 
include("function.php");
$n_controls = $_GET['numero_control'];
delete('n_control','numero_control',$n_controls);
header("location:busuarios.php");
?>