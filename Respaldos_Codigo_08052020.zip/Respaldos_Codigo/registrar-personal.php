<html>
<head>
<title>Registro de Accesos</title>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include("dash-arriba.html");?>
<?php include("boots.php");?>
<h1 align="center">Registro de Accesos.</h1>
<div align="center">
<form action="r-personal.php" method="post">
<label for="numero_control">Numero de control</label><br />
<input id="numero_control" type="text" name="numero_control" value="" placeholder="16040073"/><br /><br />
<label for="preferencia">Preferencia</label><br />
<button onclick="myFunction()"  class="btn btn-link">¿Preferencia?</button>
<script>
function myFunction() {
  alert("Se utiliza 1 para Alumnos y 2 para Preferente");
}
</script>
<br>
<select name="preferencia" id="prefernecia">
    <option>1</option>
    <option>2</option>
</select>
<br>
<br>
<br>
<input type="submit" value="Guardar">
</form>
</div>
</body>
</html>